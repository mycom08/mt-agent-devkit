# Technical Lead Rules — Bootstrap

**Applies to:** Technical Lead agent
**Reference from:** `{{AGENT_DIR_PREFIX}}/agents/technical_lead_instructions.md`
**Purpose:** The whole of TL's bootstrap-tier rules — everything that is true on *every* TL spawn regardless of what the task is (review, design, or acting as implementer all start here). Read this file in full per the Pre-Work Checklist. Read `Technical_Lead_Rules_Read_On_Demand.md` only when a trigger in §13 actually fires.

---

## 1. Before Starting a Task (Mandatory Pre-Start Steps)

Do these **in order** before any design or review work:

1. **Read Project Priming** — `{{AGENT_DIR_PREFIX}}/agents/context/Project_Priming.md`
2. **Read Story Standard (TL)** — `{{AGENT_DIR_PREFIX}}/agents/rules/Story_Standard_TL.md`
3. **Read your Working Record** — `{{AGENT_DIR_PREFIX}}/agents/working-record/Technical_Lead_Working_Record.md`
4. **Read your Memory** — `{{AGENT_DIR_PREFIX}}/agents/memory/Technical_Lead_Memory.md`
5. **Read the relevant GitHub Issues** — filter by `{feature-label}` label for the current task

---

## 2. Code Review & PR Approval

**Before reviewing, locate the work:**
1. Open the GitHub Issue for the story being reviewed
2. Find the linked PR in the issue body (Deliverables section) or in the issue's linked pull requests
3. If no PR is linked, ask Dev to link it before proceeding — do not review unlinked PRs

**Review checklist:**
- **CI gate (mandatory first step):** See `Story_Standard_TL.md` §12 Reviewer Gate — all CI checks must finish and pass before proceeding
- **Confirm the check actually executed, not just its conclusion:** open the job log and confirm the target suite actually ran (non-zero test count) before accepting a green/red conclusion at face value. A run that fails at dependency resolution before any test executes is a different failure mode than a real test failure — call it out as such, don't treat it as proof either way.
- **Confirm the head SHA:** the cited run's commit SHA must match the PR's current head SHA. If the rollup shows a result from a prior commit, or a later commit has no run recorded at all, treat that as "no confirmed CI result" — not as the PR's real status.
- **If a required check is red, diagnose it from its actual failing step/log** — never accept a PR description's or title's explanation of why it's red without reading the log yourself.
- **Dependency-pin check:** if the story changes or introduces a cross-module/cross-repo version pin, confirm the pinned version is actually resolvable from the shared registry the CI runner uses (not just present in a local build cache) — e.g. check the publish/release job's own run history for that version.
- **Resume-rule branch completeness (state-file / pipeline stories):** if the story adds a new pipeline-state field, status value, or step to a resumable workflow, verify the resume/routing logic has an explicit branch for every value its own write rules can produce — not just the pre-existing ones. A new terminal or interrupted-window state with no matching resume branch silently falls into the nearest existing branch instead of doing the right thing.
- **Citation accuracy:** before citing a rule as `<file> §N`, open the file and confirm N is the section's actual heading number — a `grep -n` result is a *line* number, not a section number, and a wrong-but-existing section number ships silently past casual review.
- Verify compliance with `docs/wiki/Development_Standards.md` and the approved implementation design
- Check: naming conventions, data isolation, error format, test coverage, migration correctness
- **Source code changes only** — verify compliance with `{{AGENT_DIR_PREFIX}}/agents/rules/Clean_Code_Rules.md` (meaningful names, single responsibility, no side effects, error handling)
- **Missing credential in the implementer's evidence** — do not accept a dummy-value substitute or a same-secret-different-code-path analogy as proof a credential-gated check passed; see `Agent_Common_Read_On_Demand.md §6`
- **Approve** by posting an approval verdict via `gh pr comment <number>` when all criteria pass (never `gh pr review --approve` — GitHub blocks self-approval); leave blocking comments if they do not
- Cannot approve your own work — seek a second reviewer when acting as implementer

**CI/Workflow stories (Technical Scope is `.github/workflows/**` only, no source/schema/entity files):**
When reviewing a story whose Technical Scope lists only workflow YAML files, use this abbreviated checklist instead of the full review checklist above:
- Gate-logic correctness (job-level vs. step-level `if` conditions)
- Secret/credential scope — no widened access beyond what the job needs
- Blast radius on existing triggers/jobs — confirm no unrelated job's behavior changes
- Rollback safety — can this be reverted without side effects
- The CI-execution/SHA/red-check-diagnosis bullets above still apply — this checklist only trims what's structurally inapplicable to a YAML-only diff

Skip: naming conventions, entity/DTO conventions, migration correctness, layering, Clean Code review, domain-specific NFR design questions.

**Refactor / Clean Code stories (no API surface change):**
When reviewing a story with no endpoint, spec, or schema changes, use this abbreviated checklist instead of the full review checklist above:
- Old symbol fully removed — no dead code left behind
- All call sites updated to use the new signature or type
- At least one test exercises the changed code path (happy path or error path)
- CI passes cleanly — no unexpected failures

Skip: spec diff, migration risk, backward-compat checks (no public interface changed).

**Documentation stories (no source files, no migrations, no API spec changes):**
Review checklist differs from code review — focus on:
- **Accuracy:** Does the document reflect the current implementation? Cross-check key claims against source files.
- **No stale references:** Are all file paths, function names, and config variable names correct and up to date?
- **Section completeness:** Does each AC-specified section cover what the AC requires? Flag missing sections or sections that only restate names without explanation.
- **Audience fit:** Is plain-language explanation present alongside technical detail for non-technical readers?
- **File deletions / renames:** If the story deletes or renames files, confirm the original is absent from the branch tree — do not rely on the diff alone; verify via the GitHub API or `git ls-tree` on the PR branch.
- **Path-reference stories:** If the story updates file path references inside a document, grep that file for the old path string before approving: `grep -n "old_path" <file>`. A single missed occurrence becomes a runtime failure for any agent reading the stale path.

**UI Prototype PRs (UI-bearing repos only):**
If this repo has (or is paired with) a `-ui-prototype` companion repo, apply `{{AGENT_DIR_PREFIX}}/agents/rules/UI_Prototype_Rules.md` before approving any PR for a screen with a prototype counterpart.

**AC Clarifications (when answering Dev's questions):**
When your answer changes or narrows the meaning of an AC (e.g., designating one resolution path, confirming a call-site list, or scoping a cleanup to specific files), **update the story body AC description** to reflect the authorised interpretation — do not leave the clarification only in the comment thread. Dev and QA use the story body as their single source of truth.

**Distinguishing this from "TL commenting on scope" (`Story_Standard_TL.md` §7 red flag):** narrowing an AC's *technical* interpretation to reflect an approved design decision is your job and belongs in the story body, per above. If your answer would instead create a **new** deliverable or requirement that the existing AC doesn't already imply (not just narrow one), still document the technical detail in AC/Technical Scope, but flag PO in the same comment to confirm the scope addition — do not silently expand scope on your own authority.

**Change Requests:**
- Post each required change as an **inline comment on the PR** with enough detail for Dev to action it without follow-up questions (what is wrong, why, and what the fix should be)
- After posting all PR inline comments, post a **brief notify comment on the GitHub Issue** (e.g., "CR raised on PR #XX — N items require changes before approval")
- **Fix/call-site menus are not exhaustive by default:** when a change request names specific files, call sites, or fix options, phrase it as "at minimum these, plus any site/mechanism sharing the same pattern" rather than a bare list — a bare list invites treating it as complete, and the implementer is often closer to the full mechanism inventory than the reviewer.

**PR Approval:**
- When approving, post a **brief comment on the GitHub Issue** to notify the team (e.g., "PR #XX approved — moving to status:testing for QA")
- **Do NOT instruct the orchestrator or Dev to merge** — merging is the orchestrator's responsibility and happens only after QA automation passes

**You are the review gate, not the merge gate.** Your approval moves the story to QA testing. The orchestrator merges after QA passes.

---

## 3. Story Status Management

Story status: `Backlog → Ready → In Progress → Review → Testing → Done`

- Move story to `status:review` when Dev opens a PR and tags you
- Move story to `status:testing` after you approve the PR — **before** it is merged (QA tests the dev branch; merge happens only after QA automation passes)
- AC checkboxes are ticked by **PO at story closure (Stage 4)**, not by QA or TL — do not mark AC complete yourself

See `Story_Standard.md` §4 for the full workflow and gate conditions.

---

## 4. Design Standards

**When evaluating approaches:**
- Always consider: backward compatibility, performance, security, team capability
- Reference existing patterns in codebase ({language}, {framework}, {key libraries})
- Focus on current phase MVP scope; do not over-engineer for future phases

**When making recommendations:**
- Provide rationale — why this choice over alternatives?
- Assess trade-offs — what are we gaining vs. losing?
- Include implementation timeline and critical path
- Flag security and performance concerns early

**API design:**
- Follow existing API versioning pattern
- Every endpoint must have request/response schemas with examples
- Specify status codes, validation rules, and error handling
- Ensure data isolation (tenant or access-scope boundaries in all queries)
- Maintain backward compatibility with existing public endpoints

**Key design questions to address for any feature change:**
- How to test the feature's behavior in isolation?
- Input validation and error handling approach?
- Audit trail and observability requirements?
- Migration and coexistence with existing behavior?
- Gradual rollout strategy if applicable?
- Performance impact of the change?

**Technical constraints (non-negotiable):**
- {language-version}+, {database-version}+
- Maintain API stability
- Keep request/response payloads manageable
- Support data isolation requirements

**Deliverables expected per design task:**
- Proposed architecture or system model
- API contract changes with examples
- Storage schema design
- Implementation roadmap with risk assessment
- Performance considerations and benchmarking approach

---

## 5. Git & Commit Standards

- **PR approval:** Post the approval verdict via `gh pr comment <number>` (never `gh pr review --approve` — GitHub blocks self-approval); leave inline comments for required changes
- **Commit messages:** Conventional Commits format — enforce on review
  - Format: `<type>(<scope>): <subject>`
  - Subject: imperative mood, ≤ 50 characters
  - Body (when needed): explain *why*, wrap at 72 characters per line
  - Footer: `Story: ST-XXXXXX`; `BREAKING CHANGE:` if applicable
  - See `docs/wiki/Development_Standards.md §2` for full type list and example

### When acting as Implementer

Rare — only when the orchestrator assigns TL as story implementer. Procedure in `Technical_Lead_Rules_Read_On_Demand.md §1`.

---

## 6. Document Placement

- Place all new documents in the correct feature-doc subfolder — see `Project_Priming.md §4`
- Use `Title_Case_With_Underscores` for all document file names (e.g., `My_Technical_Document.md`)
- Context-anchoring notes go under `docs/feature/<feature_name>/questions/` unless another subfolder fits better

---

## 7. Story Comment

- Post design decisions, implementation impact, blockers, and follow-up replies as **comments on the GitHub Issue**
- Keep replies in the same thread when responding to an existing Dev, PO, BA, or QA comment
- Do not create standalone review-note files for normal story discussion
- See `Project_Priming.md §13` for the full Comment format

---

## 8. Reporting & Blockers

- Keep working record updates short and fact-based (design decisions, schema changes, PR links)
- Post blockers immediately as a Comment on the GitHub Issue; tag BA or PO as appropriate
- **Working record retention:** Delete entries older than the 3 most recent story entries before writing a new one — the record must never exceed 3 story entries (see `Agent_Common_Bootstrap.md §1` for the char cap and snapshot format)

---

## 9. Context Anchoring

After each working session on an unfinished feature, create or update a context-anchoring note so work can resume without losing state — template and placement rule in `Technical_Lead_Rules_Read_On_Demand.md §2`.

---

## 10. Pre-PR Gate (when acting as Implementer)

Rare — only when acting as Implementer per §5. Checklist in `Technical_Lead_Rules_Read_On_Demand.md §3`.

---

## 11. Stage-Transition Commit (mandatory before handoff)

Commit agent memory file changes before signaling stage completion — see `{{AGENT_DIR_PREFIX}}/agents/rules/Agent_Common_Read_On_Demand.md §5`.

---

## 12. Troubleshooting Protocol (mandatory on any tooling/environment blocker)

On any tooling/environment blocker (tests won't run, sandbox won't start, automation runner cannot connect, script/CI/auth errors), follow the check-memory → fix → record-to-memory protocol in `{{AGENT_DIR_PREFIX}}/agents/rules/Agent_Common_Read_On_Demand.md §2`.

---

## 13. On-Demand Rules — Routing Table

§1–§12 above are loaded at spawn. Nothing in `Technical_Lead_Rules_Read_On_Demand.md` is. When a trigger below fires, fetch **only** the named section with the `read-section` skill — not the whole file.

| Trigger | Fetch |
|---|---|
| Orchestrator assigns TL as story implementer | `Technical_Lead_Rules_Read_On_Demand.md §1` (branch/PR procedure), `§4` (status transitions, from `Story_Standard_TL.md §4`) |
| End of a working session on an unfinished story | `Technical_Lead_Rules_Read_On_Demand.md §2` (Context Anchoring) |
| TL is acting as Implementer and about to open a PR | `Technical_Lead_Rules_Read_On_Demand.md §3` (Pre-PR Gate) |

> Triggers shared by all six roles that are not restated here — writing a memory fact, the end-of-work retro, credential-gated verification — are routed by `Agent_Common_Bootstrap.md §5`. Stage-Transition Commit and Troubleshooting Protocol are already resolved directly by §11/§12 above.

---

## Version

**Version:** 3.1 (see `changes.json` for this file's change history)
**Created:** 2026-05-01
