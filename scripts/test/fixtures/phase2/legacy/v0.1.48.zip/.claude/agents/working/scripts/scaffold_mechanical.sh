#!/usr/bin/env bash
# Writes every scaffold file that needs zero project-specific judgment — pure copy or
# fixed-token substitution. Run this BEFORE generating the adaptive-tier files (CLAUDE.md,
# README.md, Project_Priming.md, Document_Index.md, 6 instruction files, 10 rules files that
# need real adaptation, 4 wiki docs) so an LLM agent never has to touch content it would
# only reproduce byte-for-byte.
#
# Usage: scaffold_mechanical.sh <devkit_root> <target_project> <mode:strict|github> [github-org/repo-name]
#
# <github-org/repo-name> is optional. When omitted, {github-org}/{repo-name} tokens in rules
# files are left as literal placeholders (same convention already used for workflow files —
# fill them in manually or via a follow-up run once the GitHub repo exists).
set -euo pipefail

DEVKIT_ROOT="$1"
TARGET="$2"
MODE="$3"
GH_SLUG="${4:-}"

TPL="$DEVKIT_ROOT/.claude/agents/templates"
AGENTS="$TARGET/.claude/agents"

if [[ "$MODE" != "strict" && "$MODE" != "github" ]]; then
  echo "error: mode must be 'strict' or 'github', got '$MODE'" >&2
  exit 1
fi

# 1. Directories
mkdir -p "$AGENTS/context" "$AGENTS/memory" "$AGENTS/rules" "$AGENTS/working-record" \
         "$AGENTS/workflows" "$AGENTS/scripts" "$AGENTS/retros" "$AGENTS/tmp" "$AGENTS/docs" \
         "$TARGET/docs/wiki" "$TARGET/.claude/skills/read-section"
# No .gitkeep for retros/ — it's gitignored below (github mode) or covered by the blanket
# .claude/agents/ ignore (strict mode), so an empty-dir placeholder would never be committed.

if [[ "$MODE" == "strict" ]]; then
  mkdir -p "$AGENTS/docs/stories" "$AGENTS/docs/sprints" "$AGENTS/docs/reviews"
  echo "0" > "$AGENTS/docs/story_counter.txt"
fi


# 2. Verbatim rules files — content-diffed against real scaffold output to confirm they
#    carry no project-specific judgment beyond {github-org}/{repo-name} substitution. NOT
#    the same set Init_Project_Workflow.md's prose implies: Story_Standard_Dev/PO/QA all
#    reference a hardcoded generic API-spec location (`docs/api/`) in plain prose (no
#    {placeholder} token) that real scaffolds rewrite per-project, so those three — plus
#    the base Story_Standard.md and the three explicitly-adaptive role files — belong in
#    the adaptive tier, not here. Story_Standard_TL has no such reference and is safe.
#    Do not add a file here without re-verifying: diff a scripted copy against a known-good
#    real scaffold output for that file (byte tokens alone are not sufficient — some
#    per-project rewrites use plain prose with no {} marker at all).
VERBATIM_RULES=(
  Agent_Common_Bootstrap Agent_Common_Read_On_Demand Audit_Rules Blocked_Request
  CICD_Validation_Guide Clean_Code_Rules Product_Owner_Rules_Bootstrap
  Product_Owner_Rules_Read_On_Demand Retro_Rules
  Story_Standard_TL Strict_Mode_Story_Guide UI_Prototype_Rules
)
GH_ORG="${GH_SLUG%%/*}"
GH_REPO="${GH_SLUG##*/}"
for f in "${VERBATIM_RULES[@]}"; do
  src="$TPL/rules/${f}_template.md"
  dst="$AGENTS/rules/${f}.md"
  if [[ -n "$GH_SLUG" ]]; then
    sed -e "s/{github-org}/${GH_ORG//\//\\/}/g" -e "s/{repo-name}/${GH_REPO//\//\\/}/g" "$src" > "$dst"
  else
    cp "$src" "$dst"
  fi
  # Strip a leading UTF-8 BOM if the template carries one — devkit convention is BOM-free.
  sed -i '1s/^\xEF\xBB\xBF//' "$dst"
done

# 3. Workflow files — never adapted; {github-org}/{repo-name} and runtime-resolved placeholders
#    are intentionally left literal (except framework variables substituted at the end of this script).
NONSPLIT_WORKFLOWS=(Sync_Devkit_Workflow Workflow_Guide)
for f in "${NONSPLIT_WORKFLOWS[@]}"; do
  cp "$TPL/workflows/${f}_template.md" "$AGENTS/workflows/${f}.md"
done

SPLIT_WORKFLOWS=(
  Create_Stories_Workflow Plan_Sprint_Workflow Refine_Prototype_Workflow
  Refine_Sprint_Workflow Resume_Story_Workflow Shared_Pipeline_Stages
  Sprint_Workflow Start_Story_Workflow
)
for f in "${SPLIT_WORKFLOWS[@]}"; do
  shared="$TPL/shared/workflows/${f}_Shared_template.md"
  modefile="$TPL/$MODE/workflows/${f}_template.md"
  dst="$AGENTS/workflows/${f}.md"
  awk '/<!-- SHARED-START -->/{flag=1;next}/<!-- SHARED-END -->/{flag=0}flag' "$shared" > "$dst"

  # Mode-specific appendix: line 1 of the mode file is always a "Shared logic:" pointer
  # comment (never real content). Most mode files are ENTIRELY comments beyond that —
  # internal notes for whoever maintains the template, not content to copy — so only
  # append a separator + content when something real (non-comment, non-blank) remains.
  mode_body="$(tail -n +2 "$modefile" | grep -vE '^<!--.*-->[[:space:]]*$' || true)"
  if [[ -n "$(printf '%s' "$mode_body" | tr -d '[:space:]')" ]]; then
    trimmed="$(printf '%s\n' "$mode_body" | awk '
      NF{p=1} p{buf[++n]=$0}
      END{last=1; for(i=n;i>=1;i--){if(buf[i]!~/^[ \t]*$/){last=i;break}}
          for(i=1;i<=last;i++) print buf[i]}')"
    printf '\n---\n\n' >> "$dst"
    printf '%s\n' "$trimmed" >> "$dst"
  fi
done

# 3b. Orchestrator Instructions — shared + mode-specific combine, same mechanism as the split
#    workflow files above (step 3), but this is a single file living directly under
#    .claude/agents/, not under workflows/. Devkit-merged/protected (see CLAUDE.md's
#    Agent File Integrity table) — carries no project-specific placeholders (only framework variables substituted at the end).
og_shared="$TPL/shared/orchestrator_instructions_shared_template.md"
og_modefile="$TPL/$MODE/orchestrator_instructions_template.md"
og_dst="$AGENTS/orchestrator_instructions.md"
awk '/<!-- SHARED-START -->/{flag=1;next}/<!-- SHARED-END -->/{flag=0}flag' "$og_shared" > "$og_dst"
og_mode_body="$(tail -n +2 "$og_modefile" | grep -vE '^<!--.*-->[[:space:]]*$' || true)"
if [[ -n "$(printf '%s' "$og_mode_body" | tr -d '[:space:]')" ]]; then
  og_trimmed="$(printf '%s\n' "$og_mode_body" | awk '
    NF{p=1} p{buf[++n]=$0}
    END{last=1; for(i=n;i>=1;i--){if(buf[i]!~/^[ \t]*$/){last=i;break}}
        for(i=1;i<=last;i++) print buf[i]}')"
  printf '\n---\n\n' >> "$og_dst"
  printf '%s\n' "$og_trimmed" >> "$og_dst"
fi

# 4. Version-check scripts (verbatim)
cp "$TPL/scripts/check_devkit_version.ps1" "$AGENTS/scripts/check_devkit_version.ps1"
cp "$TPL/scripts/check_devkit_version.sh" "$AGENTS/scripts/check_devkit_version.sh"

# 4b. Shared skills — verbatim, no project-specific placeholders. Lives at
#    .claude/skills/, a sibling of .claude/agents/, not under it, since that is
#    where Claude Code discovers project-level skills.
cp "$TPL/skills/read-section/SKILL_template.md" "$TARGET/.claude/skills/read-section/SKILL.md"

# 5. devkit_version.txt
cp "$DEVKIT_ROOT/version.txt" "$AGENTS/devkit_version.txt"

# 6. Blank memory files
# Note: role_label is derived from role by replacing "_" with " " -- UI_UX_Designer is the one
# exception (its underscores are a filename-safe stand-in for "UI/UX", not word breaks), so its
# label is set explicitly rather than derived.
# Developer/QA/Technical_Lead get a two-tier live-index + archive pair (blank shape per
# Agent_Common_Read_On_Demand.md §8); Business_Analyst/Product_Owner/UI_UX_Designer keep the
# single blank-file format unchanged.
TWO_TIER_ROLES=(Developer QA Technical_Lead)
for role in Business_Analyst Developer Product_Owner QA Technical_Lead UI_UX_Designer; do
  if [[ "$role" == "UI_UX_Designer" ]]; then
    role_label="UI/UX Designer"
  else
    role_label="${role//_/ }"
  fi
  is_two_tier=false
  for r in "${TWO_TIER_ROLES[@]}"; do
    [[ "$role" == "$r" ]] && is_two_tier=true
  done
  if [[ "$is_two_tier" == true ]]; then
    printf '# %s Memory\n\n> Two-tier memory — see `Agent_Common_Read_On_Demand.md §8`. This is the lean, always-read index — titles and grep-able keywords only, no fact bodies. Full text lives in `%s_Memory_Archive.md`. Before starting a task, scan the titles and keywords below for a match; if one matches, retrieve just that fact per the §8 bounded-read recipe — never read the whole archive.\n\n## Standing Checks\n\n*(none yet — no current fact reduces to an unconditional always-do action; entries move here if a future fact qualifies)*\n\n## Keyword Index\n\n*(none yet)*\n\n## Troubleshooting Facts\n\n*(none yet)*\n' \
      "$role_label" "$role" > "$AGENTS/memory/${role}_Memory.md"
    printf '# %s Memory Archive\n\n> Full-text archive for `%s_Memory.md` Keyword Index tier — see `Agent_Common_Read_On_Demand.md §8`. Not read every spawn; open only when an index line keyword matches your current task, using the `read-section` skill (`.claude/skills/read-section/`, heading marker `^### Fact `) — never a full-file read.\n\n## Stored Facts\n\n*(none yet)*\n' \
      "$role_label" "$role" > "$AGENTS/memory/${role}_Memory_Archive.md"
  else
    printf '# %s Memory\n\nNo facts recorded yet.\n' "$role_label" > "$AGENTS/memory/${role}_Memory.md"
  fi
done

# 7. Blank working-record files (rewrite-in-place snapshot format — see the
#    *scaffolded target project's* Agent_Common_Bootstrap.md §1. The target's
#    own copy is split the same way the devkit's own working copy is.)
for role in Business_Analyst Developer Product_Owner QA Technical_Lead UI_UX_Designer; do
  if [[ "$role" == "UI_UX_Designer" ]]; then
    role_label="UI/UX Designer"
  else
    role_label="${role//_/ }"
  fi
  printf '# %s Working Record\n\n**Story:** none yet\n**Completed:** —\n**In Progress:** —\n**Impediments:** —\n\n**Blockers & Watch-outs:**\n- (none)\n' \
    "$role_label" > "$AGENTS/working-record/${role}_Working_Record.md"
done

# 8. .gitignore additions
if [[ "$MODE" == "github" ]]; then
  cat >> "$TARGET/.gitignore" <<'EOF'

# Claude Code agent temp files
.claude/agents/tmp/

# Workflow output documents
/result/

# Agent working records — ephemeral session state, no long-term git value
.claude/agents/working-record/*_Working_Record.md

# Agent retrospective files — for human review only, not part of the committed codebase
.claude/agents/retros/

# Audit workflow reports — runtime output, never committed
.claude/agents/internal/
EOF
else
  cat >> "$TARGET/.gitignore" <<'EOF'

# Claude Code agent files — all agent infrastructure and docs are local-only
.claude/agents/

# Workflow output documents
/result/
EOF
fi

# 9. VERSION + CHANGELOG.md — universal devkit convention, every language, idempotent
#    (skip if already present, e.g. a Java skeleton already wrote them before this ran).
#    See .claude/agents/working/skeletons/shared/Version_Release_Conventions.md.
if [[ ! -f "$TARGET/VERSION" ]]; then
  printf '0.0.1-SNAPSHOT' > "$TARGET/VERSION"
fi

if [[ ! -f "$TARGET/CHANGELOG.md" ]]; then
  cat > "$TARGET/CHANGELOG.md" <<'EOF'
# Changelog

All notable changes to this project are documented in this file.

## Contribution Convention

After merging a PR to main, the implementer adds a bullet entry under the relevant
subsection of the current Unreleased version below. Use the following subsections:

- **Changes** — new features, enhancements, refactors, documentation, CI/tooling
- **Bug Fixes** — defect corrections and hotfixes

Entry format: `- [ST-XXXXXX] Short description of the change.`

---

## [0.0.1] - Unreleased

### Changes

### Bug Fixes
EOF
fi

# 10. .claude/settings.json SessionStart hook — only handles the "file doesn't exist yet" case,
#    since merging into arbitrary existing JSON safely needs a real parser, not sed. If the
#    file already exists, this step is skipped and must be merged separately (this is the
#    uncommon case for brand-new repos, which is the primary caller of this script).
mkdir -p "$TARGET/.claude"
if [[ ! -f "$TARGET/.claude/settings.json" ]]; then
  UNAME_S="$(uname -s 2>/dev/null || echo unknown)"
  if [[ "$UNAME_S" == MINGW* || "$UNAME_S" == MSYS* || "${OS:-}" == "Windows_NT" ]]; then
    cat > "$TARGET/.claude/settings.json" <<'EOF'
{
  "hooks": {
    "SessionStart": [
      {
        "matcher": "startup",
        "hooks": [{ "type": "command", "command": "powershell -File .claude/agents/scripts/check_devkit_version.ps1", "timeout": 10 }]
      }
    ]
  }
}
EOF
  else
    cat > "$TARGET/.claude/settings.json" <<'EOF'
{
  "hooks": {
    "SessionStart": [
      {
        "matcher": "startup",
        "hooks": [{ "type": "command", "command": "bash .claude/agents/scripts/check_devkit_version.sh", "timeout": 10 }]
      }
    ]
  }
}
EOF
  fi
  echo "settings.json: created"
else
  echo "settings.json: already exists — SessionStart hook NOT merged, do this separately"
fi

# 11. Substitute framework placeholders in all generated mechanical files
find "$AGENTS" "$TARGET/.claude/skills" -type f \( -name "*.md" -o -name "*.sh" -o -name "*.ps1" \) -exec sed -i \
  -e 's/{{AGENT_DIR_PREFIX}}/.claude/g' \
  -e 's/{{ROOT_FILE}}/CLAUDE.md/g' \
  -e 's/{{AGENT_CLI_NAME}}/Claude Code/g' {} +

echo "Mechanical scaffold complete: $TARGET"
